
const connectorConfig = {
  connector: 'default',
  service: 'c',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
